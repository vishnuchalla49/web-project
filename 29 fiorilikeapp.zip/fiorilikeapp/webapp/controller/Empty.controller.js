sap.ui.define([
    'ey/hr/payroll/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("ey.hr.payroll.controller.Empty",{
        init: function(){
            
        }
    });
});